
package t3a5;

public class Cuenta {
    
    private String numeroDeCuenta;
    private int pin;
    private float saldo;

    public Cuenta(){
    
        
    }

    public Cuenta(String numeroDeCuenta, int pin, float saldo) {
        this.numeroDeCuenta = numeroDeCuenta;
        this.pin = pin;
        this.saldo = saldo;
    }
    
    public void consultarSaldo(){
        saldo = 753.50f;
        System.out.println("Tienes un saldo de: " + getSaldo());
    }
    
    public void estadoDeCuenta(){
        System.out.println("ESTADO DE CUENTA\n\n"
                + "Cuenta: " + getNumeroDeCuenta()
                + "\n Saldo: " + getSaldo()
                + "\n\nUltimos Movimientos ");
    }
    
    public void retiroEfectivo(){
        if (getSaldo() > 0) {
            System.out.println("?Cuanto Desea Retirar?");
        } else { System.out.println("NO PUEDO AYUDARTE CON ESA OPERACION"
                + "\nFONDOS INSUFICIENTES");
            
        }
    }
    
    public void seguros(){
        System.out.println("SEGUROS"
                + "\n1. Hipotecario"
                + "\n2. Crediauto"
                + "\n3. Familiar"
                + "\n4. Personal");
    }
    
    public void creditos(){
        System.out.println("Creditos"
                + "\n1. Hipotecario"
                + "\n2. Crediauto"
                + "\n3. Familiar"
                + "\n4. Personal");
    }
    
    public void salir(){
        System.out.println("Graciotas..");
    }
    
    @Override
    public String toString(){
        String mensaje = "Numero de cuenta: " + numeroDeCuenta;
        return mensaje;
        
    }
    
    public String getNumeroDeCuenta() {
        return numeroDeCuenta;
    }

    public void setNumeroDeCuenta(String numeroDeCuenta) {
        this.numeroDeCuenta = numeroDeCuenta;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
    
    
}
